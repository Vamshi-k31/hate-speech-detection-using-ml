import numpy as np
import re
import string
from flask import Flask, render_template, request, redirect, url_for, session, flash
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pickle
import firebase_admin
from firebase_admin import credentials, firestore

# Load the trained model and tokenizer
model_path = "C:/Users/rashm/Downloads/house/hate_speech_cnn_model.h5"
tokenizer_path = "C:/Users/rashm/Downloads/house/tokenizer.pkl"

model = load_model(model_path)
with open(tokenizer_path, "rb") as f:
    tokenizer = pickle.load(f)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = "your_secret_key"  # Replace with a secure secret key

cred = credentials.Certificate("C:/Users/rashm/Downloads/house/tweeter-hatespeech-detection.json")  


firebase_admin.initialize_app(cred)
db = firestore.client() 

# Preprocessing function
def preprocess_text(text):
    if isinstance(text, str):  # Check if the input is a string
        text = text.lower()  # Lowercase
        text = re.sub(r"http\S+|www\S+|https\S+", "", text, flags=re.MULTILINE)  # Remove URLs
        text = re.sub(r"@\w+", "", text)  # Remove mentions
        text = re.sub(r"#", "", text)  # Remove hashtags
        text = text.translate(str.maketrans("", "", string.punctuation))  # Remove punctuation
        return text.strip()
    return ""

# Prediction function
def predict_hate_speech(tweet):
    # Preprocess the input text
    processed_tweet = preprocess_text(tweet)

    # Tokenize and pad the text
    max_len = 120
    sequences = tokenizer.texts_to_sequences([processed_tweet])
    x_data = pad_sequences(sequences, maxlen=max_len)

    # Predict using the model
    prediction = model.predict(x_data)[0][0]  # Sigmoid output for binary classification
    hate_percentage = prediction * 100
    # Interpret the prediction
    
    result = "Hate Speech Detected" if prediction > 0.57 else "Hate Speech Not Detected"
    return result, hate_percentage

# Save prediction to Firebase Firestore
def save_prediction_to_firebase(tweet, result, hate_percentage):
    doc_ref = db.collection("predictions").document()
    doc_ref.set({
        "tweet": tweet,
        "result": result,
        "percentages": f"{hate_percentage:.2f}%"
    })

# Retrieve prediction history from Firebase Firestore
def get_prediction_history():
    predictions = []
    docs = db.collection("predictions").stream()
    for doc in docs:
        predictions.append(doc.to_dict())
    return predictions

# Routes
@app.route('/')
def home():
    return redirect(url_for('login'))



@app.route('/index', methods=['GET', 'POST'])
def index():
    if 'logged_in' not in session:
        return redirect(url_for('login'))

    result = None  # Default result
    hate_percentage = None  # Initialize hate_percentage to None to avoid the error

    if request.method == 'POST':
        tweet = request.form['tweet']
        result, hate_percentage = predict_hate_speech(tweet)
        hate_percentage = round(hate_percentage, 2)

        # Save the prediction to Firebase
        save_prediction_to_firebase(tweet, result, hate_percentage)

    return render_template('index.html', result=result, hate_percentage=hate_percentage)



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check credentials
        if username == "vamshi@gmail.com" and password == "password123":  
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            flash("Invalid credentials. Please try again.")
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/history')
def history():
    if 'logged_in' not in session:
        return redirect(url_for('login'))

    # Retrieve prediction history from Firebase
    history = get_prediction_history()

    return render_template('history.html', history=history)

if __name__ == "__main__":
    app.run(debug=True)
