import pandas as pd
import numpy as np
import re
import string
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Conv1D, GlobalMaxPooling1D, Dense, Dropout
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping
import pickle

# Load the dataset
df = pd.read_csv("C:/Users/rashm/Downloads/house/labeled_data.csv")

# Ensure the 'class' column exists and contains valid numeric labels
if 'class' not in df.columns:
    raise ValueError("'class' column not found in the dataset.")

# Convert the 'class' column to binary (1 for hate speech, 0 for others)
df['class'] = df['class'].apply(lambda x: 1 if x == 1 else 0)  # Ensure numeric labels

# Drop rows with missing values in 'tweet' or 'class'
df = df.dropna(subset=['tweet', 'class'])

# Preprocess the 'tweet' column
def preprocess_text(text):
    if isinstance(text, str):  # Check if the input is a string
        text = text.lower()  # Lowercase
        text = re.sub(r"http\S+|www\S+|https\S+", "", text, flags=re.MULTILINE)  # Remove URLs
        text = re.sub(r"@\w+", "", text)  # Remove mentions
        text = re.sub(r"#", "", text)  # Remove hashtags
        text = text.translate(str.maketrans("", "", string.punctuation))  # Remove punctuation
        return text.strip()
    return ""

df['tweet'] = df['tweet'].apply(preprocess_text)

# Prepare data
tweets = df['tweet'].values
labels = df['class'].values

# Tokenization
max_words = 15000
max_len = 120
tokenizer = Tokenizer(num_words=max_words, oov_token="<OOV>")
tokenizer.fit_on_texts(tweets)
sequences = tokenizer.texts_to_sequences(tweets)
x_data = pad_sequences(sequences, maxlen=max_len)

# Train-test split
x_train, x_test, y_train, y_test = train_test_split(
    x_data, labels, test_size=0.2, random_state=42, stratify=labels
)

# Build the CNN model for binary classification
model = Sequential([
    Embedding(max_words, 128, input_length=max_len),
    Conv1D(256, 5, activation='relu'),
    GlobalMaxPooling1D(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(1, activation='sigmoid')  # Binary classification
])

# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Early stopping
early_stop = EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)

# Train the model
history = model.fit(
    x_train, y_train,
    epochs=10,
    batch_size=64,
    validation_data=(x_test, y_test),
    class_weight={0: 1.0, 1: 1.5},  # Example class weights
    callbacks=[early_stop]
)

# Save the model and tokenizer
model.save("C:/Users/rashm/Downloads/house/hate_speech_cnn_model.h5")
with open("C:/Users/rashm/Downloads/house/tokenizer.pkl", "wb") as f:
    pickle.dump(tokenizer, f)

print("Model and tokenizer saved.")
